# The internal API layout doesn't follow any particular paradigm:
# we simply organize code in different modules, depending on what the code is used for.
